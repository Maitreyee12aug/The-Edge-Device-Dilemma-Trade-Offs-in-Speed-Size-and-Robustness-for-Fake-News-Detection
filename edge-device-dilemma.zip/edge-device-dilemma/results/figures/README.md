# Generated figures are saved here by the experiment scripts.
#
# Files produced:
#   figure4_efficiency_frontier.png   — Phase I: Accuracy vs Latency vs Size (Figure 4)
#   figure5_generalisation_gap.png    — Phase II: Bidirectional zero-shot decay (Figure 5)
#   table9_ablation_study.png         — Ablation: Feature configuration comparison (Table 9)
#   figure8_dynamic_cascade.png       — Dynamic Inference Cascading trajectory (Figure 8)
#
# Run the scripts in order to regenerate all figures:
#   python scripts/01_phase1_efficiency.py
#   python scripts/02_phase2_robustness.py
#   python scripts/03_ablation_study.py
#   python scripts/04_dynamic_cascade.py
