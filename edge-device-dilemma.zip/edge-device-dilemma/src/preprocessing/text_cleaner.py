"""
src/preprocessing/text_cleaner.py

Low-latency text preprocessing pipeline for edge deployment.
Avoids computationally expensive operations (lemmatization, POS tagging,
dependency parsing) in favour of regex-based cleaning and whitespace
tokenisation, as described in §3.2 of the paper.
"""

import re
import string
import warnings

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

warnings.filterwarnings("ignore", category=UserWarning)

# Download NLTK assets quietly on first import
for _resource in ("stopwords", "punkt", "punkt_tab"):
    nltk.download(_resource, quiet=True)

_STOP_WORDS = set(stopwords.words("english"))


def preprocess_text(text: str, remove_stopwords: bool = True) -> str:
    """
    Clean and normalise a single document for vectorisation.

    Steps (paper §3.2):
      1. Lowercase
      2. Strip URLs (regex)
      3. Strip @mentions
      4. Remove '#' symbol (keep the word)
      5. Remove punctuation
      6. Whitespace tokenisation
      7. Stopword removal (optional)

    Parameters
    ----------
    text : str
        Raw input text.
    remove_stopwords : bool
        Whether to remove English stopwords (default True).

    Returns
    -------
    str
        Space-joined cleaned tokens.
    """
    text = str(text).lower()
    text = re.sub(r"https?://\S+", "", text)   # URLs
    text = re.sub(r"@\w+", "", text)            # Mentions
    text = text.replace("#", "")                # Hashtag symbol
    text = text.translate(str.maketrans("", "", string.punctuation))
    tokens = word_tokenize(text)
    if remove_stopwords:
        tokens = [w for w in tokens if w not in _STOP_WORDS]
    return " ".join(tokens)


def preprocess_series(series, remove_stopwords: bool = True, show_progress: bool = True):
    """
    Apply `preprocess_text` to a pandas Series.

    Parameters
    ----------
    series : pd.Series
        Series of raw text strings.
    remove_stopwords : bool
        Passed through to `preprocess_text`.
    show_progress : bool
        If True and tqdm is available, display a progress bar.

    Returns
    -------
    pd.Series
        Cleaned text series.
    """
    try:
        from tqdm import tqdm
        tqdm.pandas(desc="Preprocessing")
        if show_progress:
            return series.progress_apply(
                lambda t: preprocess_text(t, remove_stopwords)
            )
    except ImportError:
        pass
    return series.apply(lambda t: preprocess_text(t, remove_stopwords))
