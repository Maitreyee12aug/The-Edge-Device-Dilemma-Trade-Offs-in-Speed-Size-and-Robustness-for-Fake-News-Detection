"""
src/models/dynamic_cascade.py

Dynamic Inference Cascading framework (paper §6.1).

Two-tier "Adaptive Throttle" system:
  Tier 1 (Fast Path)   — Hashing-SVC; handles high-confidence in-domain inputs
                         at ≈0.14 ms with negligible power consumption.
  Tier 2 (Robust Path) — Hybrid Super-Vector; selectively invoked when
                         classifier confidence |s| < τ (domain drift detected).

Under typical in-domain conditions the system routes ~97% of requests through
Tier 1, maintaining mean latency ≈0.6 ms while recovering accuracy to ≈93%+
during domain drift events (paper §6.2, Figure 8).
"""

import time

import numpy as np
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import accuracy_score


# ---------------------------------------------------------------------------
# Cascade system
# ---------------------------------------------------------------------------

class DynamicInferenceCascade:
    """
    Resource-aware model switching (paper §6.1).

    Parameters
    ----------
    tier1_pipeline : fitted sklearn Pipeline (Hashing-SVC)
        The fast-path lightweight classifier.
    tier2_featurizer : fitted SuperVectorFeaturizer
        Feature extractor for the robust path.
    tier2_classifier : fitted LinearSVC
        Robust-path classifier operating on Super-Vector features.
    confidence_threshold : float
        Samples with |decision score| < threshold are escalated to Tier 2.
        Paper uses τ = 0.3 (configs/config.yaml → cascade.confidence_threshold).
    """

    def __init__(
        self,
        tier1_pipeline,
        tier2_featurizer,
        tier2_classifier,
        confidence_threshold: float = 0.3,
    ):
        self.tier1 = tier1_pipeline
        self.tier2_featurizer = tier2_featurizer
        self.tier2_classifier = tier2_classifier
        self.tau = confidence_threshold

        self._tier1_count = 0
        self._tier2_count = 0

    # ------------------------------------------------------------------
    def predict(self, X_cleaned, X_raw=None):
        """
        Predict labels using the cascade routing logic.

        Parameters
        ----------
        X_cleaned : array-like of str
            Pre-processed text (required for Tier 1).
        X_raw : array-like of str or None
            Original text (required for Tier 2; if None, Tier 2 uses X_cleaned).

        Returns
        -------
        np.ndarray of int labels
        """
        X_cleaned = list(X_cleaned)
        n = len(X_cleaned)
        final_preds = np.zeros(n, dtype=int)

        # --- Tier 1 ---
        scores = self.tier1.decision_function(X_cleaned)
        confidence = np.abs(scores)
        high_conf_mask = confidence >= self.tau
        low_conf_mask  = ~high_conf_mask

        # Accept Tier 1 predictions for confident samples
        tier1_preds = (scores > 0).astype(int)
        final_preds[high_conf_mask] = tier1_preds[high_conf_mask]
        self._tier1_count += int(high_conf_mask.sum())

        # --- Tier 2 (escalation) ---
        if low_conf_mask.any():
            idx = np.where(low_conf_mask)[0]
            x_cleaned_2 = [X_cleaned[i] for i in idx]
            x_raw_2 = [X_raw[i] for i in idx] if X_raw is not None else x_cleaned_2

            X2 = self.tier2_featurizer.transform(x_raw_2, x_cleaned_2)
            tier2_preds = self.tier2_classifier.predict(X2)
            final_preds[idx] = tier2_preds
            self._tier2_count += len(idx)

        return final_preds

    # ------------------------------------------------------------------
    @property
    def tier1_ratio(self) -> float:
        total = self._tier1_count + self._tier2_count
        return self._tier1_count / total if total > 0 else 1.0

    def reset_counters(self):
        self._tier1_count = 0
        self._tier2_count = 0


# ---------------------------------------------------------------------------
# Stream simulation (paper §6.2, Figure 8)
# ---------------------------------------------------------------------------

def run_stream_simulation(
    cascade: DynamicInferenceCascade,
    X_phase_a_cleaned, y_phase_a,       # In-domain (Political)
    X_phase_b_cleaned, y_phase_b,       # Drift domain (COVID-19)
    X_phase_a_raw=None,
    X_phase_b_raw=None,
    window: int = 50,
) -> dict:
    """
    Simulate a continuous data stream with a sudden domain shift at the
    boundary between phase_a and phase_b data (paper §6.2).

    Parameters
    ----------
    cascade : DynamicInferenceCascade
    X_phase_a_cleaned, y_phase_a : in-domain Political data
    X_phase_b_cleaned, y_phase_b : drift COVID-19 data
    window : int
        Rolling accuracy window size for smoothing.

    Returns
    -------
    dict with keys:
        rolling_accuracy : list of float
        mean_latency_ms  : float
        tier1_ratio      : float
    """
    X_all_cleaned = list(X_phase_a_cleaned) + list(X_phase_b_cleaned)
    X_all_raw     = (
        list(X_phase_a_raw) + list(X_phase_b_raw)
        if X_phase_a_raw is not None else None
    )
    y_all = list(y_phase_a) + list(y_phase_b)

    n = len(y_all)
    rolling_acc = []
    latency_log = []
    correct_window = []
    cascade.reset_counters()

    for i in range(n):
        x_c = [X_all_cleaned[i]]
        x_r = [X_all_raw[i]] if X_all_raw else None

        t0 = time.perf_counter_ns()
        pred = cascade.predict(x_c, x_r)[0]
        t1 = time.perf_counter_ns()

        latency_log.append((t1 - t0) / 1e6)
        correct_window.append(int(pred == y_all[i]))

        if len(correct_window) > window:
            correct_window.pop(0)
        rolling_acc.append(sum(correct_window) / len(correct_window))

    return {
        "rolling_accuracy": rolling_acc,
        "mean_latency_ms":  float(sum(latency_log) / len(latency_log)),
        "tier1_ratio":      cascade.tier1_ratio,
        "n_phase_a":        len(y_phase_a),
        "n_phase_b":        len(y_phase_b),
    }
