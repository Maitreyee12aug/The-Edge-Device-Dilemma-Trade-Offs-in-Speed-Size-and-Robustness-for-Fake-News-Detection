"""
src/models/bert_model.py

BERT baseline for fake news detection (paper §3.3.4, Paradigm 4).

Uses `bert-base-uncased` to establish the performance ceiling.
The O(n²) self-attention mechanism incurs >125 ms latency on mobile
hardware, making it unsuitable for real-time edge deployment despite
its high in-domain accuracy.

GPU is strongly recommended (CUDA or MPS). CPU training will be very slow.
"""

import time

import numpy as np
import torch
from sklearn.metrics import accuracy_score, f1_score
from torch.optim import AdamW
from torch.utils.data import DataLoader, Dataset
from transformers import BertForSequenceClassification, BertTokenizer


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------

class FakeNewsDataset(Dataset):
    """PyTorch Dataset for tokenised fake-news text."""

    def __init__(self, texts, labels, tokenizer, max_len: int):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_len = max_len

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        encoding = self.tokenizer.encode_plus(
            str(self.texts[idx]),
            add_special_tokens=True,
            max_length=self.max_len,
            return_token_type_ids=False,
            padding="max_length",
            truncation=True,
            return_attention_mask=True,
            return_tensors="pt",
        )
        return {
            "input_ids":      encoding["input_ids"].flatten(),
            "attention_mask": encoding["attention_mask"].flatten(),
            "labels":         torch.tensor(self.labels[idx], dtype=torch.long),
        }


# ---------------------------------------------------------------------------
# Training loop
# ---------------------------------------------------------------------------

def train_one_epoch(model, data_loader, optimizer, device):
    """Run a single training epoch. Returns (accuracy, mean_loss)."""
    model.train()
    total_loss, correct, n = 0.0, 0, 0

    for batch in data_loader:
        ids  = batch["input_ids"].to(device)
        mask = batch["attention_mask"].to(device)
        lbls = batch["labels"].to(device)

        outputs = model(input_ids=ids, attention_mask=mask, labels=lbls)
        loss = outputs.loss
        preds = torch.argmax(outputs.logits, dim=1)

        correct += (preds == lbls).sum().item()
        total_loss += loss.item()
        n += len(lbls)

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

    return correct / n, total_loss / len(data_loader)


# ---------------------------------------------------------------------------
# Evaluation loop
# ---------------------------------------------------------------------------

def evaluate(model, data_loader, device):
    """
    Evaluate model on a DataLoader (batch_size=1 for edge latency simulation).

    Returns
    -------
    dict with keys: accuracy, f1, avg_latency_ms
    """
    model.eval()
    all_preds, all_labels, latencies = [], [], []

    with torch.no_grad():
        for batch in data_loader:
            ids  = batch["input_ids"].to(device)
            mask = batch["attention_mask"].to(device)
            lbls = batch["labels"].to(device)

            t0 = time.perf_counter_ns()
            outputs = model(input_ids=ids, attention_mask=mask, labels=lbls)
            t1 = time.perf_counter_ns()

            # Per-sample latency (ms)
            latencies.append((t1 - t0) / 1e6 / len(ids))

            preds = torch.argmax(outputs.logits, dim=1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(lbls.cpu().numpy())

    return {
        "accuracy":       accuracy_score(all_labels, all_preds),
        "f1":             f1_score(all_labels, all_preds, average="macro"),
        "avg_latency_ms": float(np.mean(latencies)),
    }


# ---------------------------------------------------------------------------
# Main experiment runner
# ---------------------------------------------------------------------------

def run_bert_experiment(
    src_texts, src_labels,
    tgt_texts, tgt_labels,
    cfg: dict,
) -> dict:
    """
    Full BERT experiment: train on source domain, evaluate on both source
    and target domains (zero-shot cross-domain transfer).

    Parameters
    ----------
    src_texts, src_labels : source domain data (Political corpus)
    tgt_texts, tgt_labels : target domain data (COVID-19 corpus)
    cfg : config dict loaded from configs/config.yaml

    Returns
    -------
    dict with source + target accuracy, F1, latency
    """
    bcfg  = cfg["models"]["bert"]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[BERT] Running on: {device}")
    if device.type == "cpu":
        print("[BERT] WARNING: CPU training will be very slow. Use a GPU.")

    tokenizer = BertTokenizer.from_pretrained(bcfg["model_name"])

    # Build datasets / loaders
    ds_train = FakeNewsDataset(src_texts, src_labels, tokenizer, bcfg["max_len"])
    dl_train = DataLoader(ds_train, batch_size=bcfg["batch_size"], shuffle=True)

    subset = min(500, len(src_texts))
    ds_src_eval = FakeNewsDataset(src_texts[:subset], src_labels[:subset], tokenizer, bcfg["max_len"])
    dl_src_eval = DataLoader(ds_src_eval, batch_size=1)

    ds_tgt = FakeNewsDataset(tgt_texts, tgt_labels, tokenizer, bcfg["max_len"])
    dl_tgt = DataLoader(ds_tgt, batch_size=1)

    # Model
    model = BertForSequenceClassification.from_pretrained(
        bcfg["model_name"], num_labels=2
    ).to(device)
    optimizer = AdamW(model.parameters(), lr=bcfg["learning_rate"])

    # Training
    for epoch in range(bcfg["epochs"]):
        acc, loss = train_one_epoch(model, dl_train, optimizer, device)
        print(f"  Epoch {epoch + 1}/{bcfg['epochs']} — acc={acc:.4f}, loss={loss:.4f}")

    # Evaluation
    src_metrics = evaluate(model, dl_src_eval, device)
    tgt_metrics = evaluate(model, dl_tgt, device)

    delta    = src_metrics["accuracy"] - tgt_metrics["accuracy"]
    rho      = delta / src_metrics["accuracy"] * 100

    results = {
        "source_accuracy":  src_metrics["accuracy"],
        "source_f1":        src_metrics["f1"],
        "target_accuracy":  tgt_metrics["accuracy"],
        "target_f1":        tgt_metrics["f1"],
        "delta":            delta,
        "rho_pct":          rho,
        "avg_latency_ms":   tgt_metrics["avg_latency_ms"],
        "model_size_mb":    440.0,   # bert-base-uncased standard size
    }

    print("\n" + "=" * 45)
    print("  BERT EXPERIMENTAL RESULTS")
    print("=" * 45)
    print(f"  Source Accuracy : {results['source_accuracy']:.2%}")
    print(f"  Target Accuracy : {results['target_accuracy']:.2%}")
    print(f"  Decay (Δ)       : {results['delta']:.2%}  [ρ = {results['rho_pct']:.1f}%]")
    print(f"  Latency (avg)   : {results['avg_latency_ms']:.2f} ms")
    print("=" * 45)

    return results
