"""
src/models/lightweight_models.py

Lightweight text classification paradigms (paper §3.3):

  P1a — Hashing-SVC  (memory lower-bound; O(k) complexity)
  P1b — TF-IDF-SVC   (vocabulary-dependent baseline; O(|V|) complexity)
  P2  — fastText     (sub-word embeddings + hierarchical softmax; O(log C))
  P3  — Super-Vector (hybrid lexical + stylistic; O(k) + O(n))

Each model is wrapped in a small builder function that accepts a config
dict (matching configs/config.yaml) and returns a ready-to-use object.
"""

import os
import time

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import HashingVectorizer, TfidfVectorizer
from sklearn.metrics import accuracy_score, f1_score
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC


# ---------------------------------------------------------------------------
# Helper — fastText file formatter
# ---------------------------------------------------------------------------

def _write_fasttext_file(texts, labels, filepath: str) -> None:
    """Write data to fastText's labelled training format."""
    with open(filepath, "w", encoding="utf-8") as f:
        for text, label in zip(texts, labels):
            f.write(f"__label__{label} {text}\n")


# ---------------------------------------------------------------------------
# P1a: Hashing-SVC
# ---------------------------------------------------------------------------

def build_hashing_svc(cfg: dict) -> Pipeline:
    """
    Build the memory-optimal Hashing-SVC pipeline (paper §3.3.1-B).

    The feature mapping ϕ(x) uses a stateless hash function, completely
    eliminating vocabulary storage. With d = 2^18, collision variance is
    negligible for fake-news datasets (paper §5.2).
    """
    hcfg = cfg["models"]["hashing_svc"]
    return Pipeline([
        ("vectorizer", HashingVectorizer(
            n_features=hcfg["n_features"],
            ngram_range=tuple(hcfg["ngram_range"]),
        )),
        ("classifier", LinearSVC(
            C=hcfg["svc_C"],
            random_state=42,
            dual=hcfg["svc_dual"],
            max_iter=hcfg["svc_max_iter"],
        )),
    ])


# ---------------------------------------------------------------------------
# P1b: TF-IDF-SVC
# ---------------------------------------------------------------------------

def build_tfidf_svc(cfg: dict) -> Pipeline:
    """
    Build the TF-IDF + LinearSVC pipeline (paper §3.3.1-A).

    Requires storing the full IDF-weighted vocabulary (O(|V|) memory).
    Used as the interpretable in-domain baseline.
    """
    tcfg = cfg["models"]["tfidf_svc"]
    return Pipeline([
        ("vectorizer", TfidfVectorizer(ngram_range=tuple(tcfg["ngram_range"]))),
        ("classifier", LinearSVC(
            C=tcfg["svc_C"],
            random_state=42,
            dual=tcfg["svc_dual"],
            max_iter=tcfg["svc_max_iter"],
        )),
    ])


# ---------------------------------------------------------------------------
# P2: fastText
# ---------------------------------------------------------------------------

def train_fasttext(X_train_cleaned, y_train, cfg: dict):
    """
    Train a fastText model (paper §3.3.2) using the paper's hyperparameters.

    Writes a temporary training file, trains with fasttext, then cleans up.

    Returns
    -------
    model : fasttext.FastText._FastText
    """
    try:
        import fasttext
    except ImportError:
        raise ImportError(
            "fasttext is not installed. Run: pip install fasttext-wheel"
        )

    ftcfg = cfg["models"]["fasttext"]
    tmp_file = "_ft_train_tmp.txt"
    _write_fasttext_file(X_train_cleaned, y_train, tmp_file)

    model = fasttext.train_supervised(
        input=tmp_file,
        lr=ftcfg["lr"],
        dim=ftcfg["dim"],
        epoch=ftcfg["epoch"],
        wordNgrams=ftcfg["wordNgrams"],
        verbose=ftcfg.get("verbose", 0),
    )

    os.remove(tmp_file)
    return model


def predict_fasttext(model, X_cleaned) -> np.ndarray:
    """Run batch prediction with a fastText model, returning integer labels."""
    texts = list(X_cleaned)
    label_lists, _ = model.predict(texts, k=1)
    return np.array(
        [int(lbl[0].split("__label__")[1]) for lbl in label_lists]
    )


def get_fasttext_size_mb(model) -> float:
    """Serialize fastText model to disk and return size in MB, then clean up."""
    tmp = "_ft_size_tmp.bin"
    model.save_model(tmp)
    size = os.path.getsize(tmp) / (1024 * 1024)
    os.remove(tmp)
    return size


# ---------------------------------------------------------------------------
# P3: Super-Vector (imported from feature_engineering)
# ---------------------------------------------------------------------------

def build_super_vector_model(cfg: dict):
    """
    Build the Hybrid Super-Vector classifier (paper §3.3.3).

    Returns a (SuperVectorFeaturizer, LinearSVC) tuple — these must be
    used together because the featurizer requires two inputs (raw + cleaned).
    """
    from src.features.feature_engineering import SuperVectorFeaturizer

    svcfg = cfg["models"]["super_vector"]
    featurizer = SuperVectorFeaturizer(
        n_hash_features=svcfg["n_hash_features"],
        n_tfidf_features=svcfg["n_tfidf_features"],
    )
    classifier = LinearSVC(
        C=svcfg["svc_C"],
        random_state=42,
        dual=svcfg["svc_dual"],
        max_iter=svcfg["svc_max_iter"],
    )
    return featurizer, classifier


# ---------------------------------------------------------------------------
# Shared — model footprint measurement
# ---------------------------------------------------------------------------

def get_sklearn_size_mb(model) -> float:
    """
    Serialize a sklearn model with joblib and return its disk size in MB.
    """
    import joblib

    tmp = "_model_size_tmp.joblib"
    joblib.dump(model, tmp)
    size = os.path.getsize(tmp) / (1024 * 1024)
    os.remove(tmp)
    return size
