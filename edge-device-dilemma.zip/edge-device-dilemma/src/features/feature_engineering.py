"""
src/features/feature_engineering.py

Hybrid "Super-Vector" feature engineering (paper §3.3.3, Table 3).

The Super-Vector concatenates:
  v_lex  — sparse hashed lexical features (HashingVectorizer)
  v_style — dense stylistic features (VADER sentiment + readability + ratios)

These two complementary representations capture both domain-specific
keywords and domain-invariant "structural fingerprints" of fake news,
yielding better zero-shot cross-domain generalisation than either alone
(ablation study §4.7).
"""

import string
import warnings

import numpy as np
from scipy.sparse import hstack, csr_matrix
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_extraction.text import HashingVectorizer, TfidfVectorizer
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore", category=UserWarning)

# ---------------------------------------------------------------------------
# Stylistic feature extraction
# ---------------------------------------------------------------------------

try:
    import textstat
    _TEXTSTAT_AVAILABLE = True
except ImportError:
    _TEXTSTAT_AVAILABLE = False

try:
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
    _vader_analyzer = SentimentIntensityAnalyzer()
    _VADER_AVAILABLE = True
except ImportError:
    _VADER_AVAILABLE = False


def get_stylistic_features(raw_text: str) -> list:
    """
    Extract the 14-dimensional stylistic feature vector (v_style) described
    in Table 3 of the paper.

    Features
    --------
    Sentiment (VADER):   neg, neu, pos, compound
    Readability:         Flesch Reading Ease, Gunning Fog, ARI,
                         lexicon count, sentence count
    Structural ratios:   char count, word count, upper-case ratio,
                         punctuation ratio

    Returns
    -------
    list of float  (length 13; gracefully degrades when libraries absent)
    """
    raw_text = str(raw_text)

    # --- Sentiment ---
    if _VADER_AVAILABLE:
        try:
            s = _vader_analyzer.polarity_scores(raw_text)
            neg, neu, pos, compound = s["neg"], s["neu"], s["pos"], s["compound"]
        except Exception:
            neg = neu = pos = compound = 0.0
    else:
        neg = neu = pos = compound = 0.0

    # --- Readability ---
    if _TEXTSTAT_AVAILABLE:
        try:
            flesch = textstat.flesch_reading_ease(raw_text)
            fog = textstat.gunning_fog(raw_text)
            ari = textstat.automated_readability_index(raw_text)
            lexicon = textstat.lexicon_count(raw_text)
            sentences = textstat.sentence_count(raw_text)
        except Exception:
            flesch = fog = ari = lexicon = sentences = 0.0
    else:
        flesch = fog = ari = lexicon = sentences = 0.0

    # --- Structural ratios ---
    char_count = len(raw_text)
    word_count = len(raw_text.split())
    upper_count = sum(1 for c in raw_text if c.isupper())
    upper_ratio = upper_count / (char_count + 1e-6)
    punct_count = sum(1 for c in raw_text if c in string.punctuation)
    punct_ratio = punct_count / (char_count + 1e-6)

    return [
        neg, neu, pos, compound,
        flesch, fog, ari, lexicon, sentences,
        char_count, word_count, upper_ratio, punct_ratio,
    ]


# ---------------------------------------------------------------------------
# scikit-learn compatible transformer (used in FeatureUnion pipelines)
# ---------------------------------------------------------------------------

class StylisticFeaturesExtractor(BaseEstimator, TransformerMixin):
    """sklearn transformer wrapper around `get_stylistic_features`."""

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return np.array([get_stylistic_features(t) for t in X])

    def get_feature_names_out(self, input_features=None):
        return [
            "sent_neg", "sent_neu", "sent_pos", "sent_compound",
            "flesch", "fog", "ari", "lexicon", "sentences",
            "char_count", "word_count", "upper_ratio", "punct_ratio",
        ]


# ---------------------------------------------------------------------------
# SuperVectorFeaturizer — the full hybrid featurizer
# ---------------------------------------------------------------------------

class SuperVectorFeaturizer:
    """
    Builds the hybrid Super-Vector representation:

        v_final = v_lex ⊕ v_style

    where ⊕ denotes horizontal concatenation (scipy sparse hstack).

    Parameters
    ----------
    n_hash_features : int
        Dimension of the HashingVectorizer feature space (default 2^14 = 16384).
    n_tfidf_features : int
        Vocabulary size of the supplementary lightweight TF-IDF component
        (default 2000).
    ngram_range : tuple
        N-gram range for both lexical vectorisers (default (1, 2)).
    """

    def __init__(
        self,
        n_hash_features: int = 2 ** 14,
        n_tfidf_features: int = 2000,
        ngram_range: tuple = (1, 2),
    ):
        self.n_hash_features = n_hash_features
        self.n_tfidf_features = n_tfidf_features
        self.ngram_range = ngram_range

        self.stylistic_scaler = StandardScaler()
        self.hash_vectorizer = HashingVectorizer(
            n_features=n_hash_features, ngram_range=ngram_range
        )
        self.tfidf_vectorizer = TfidfVectorizer(
            ngram_range=ngram_range, max_features=n_tfidf_features
        )

    # ------------------------------------------------------------------
    def _extract_stylistic(self, raw_texts) -> np.ndarray:
        return np.array([get_stylistic_features(t) for t in raw_texts])

    # ------------------------------------------------------------------
    def fit(self, X_raw, X_cleaned):
        """
        Fit the stylistic scaler and TF-IDF vocabulary.

        Parameters
        ----------
        X_raw : iterable of str
            Original (un-preprocessed) text — required for VADER / readability.
        X_cleaned : iterable of str
            Pre-processed text — used for lexical vectorisers.
        """
        stylistic = self._extract_stylistic(X_raw)
        self.stylistic_scaler.fit(stylistic)
        self.tfidf_vectorizer.fit(X_cleaned)
        return self

    # ------------------------------------------------------------------
    def transform(self, X_raw, X_cleaned):
        """
        Transform text into the Super-Vector representation.

        Returns
        -------
        scipy.sparse matrix of shape (n_samples, n_hash + n_tfidf + n_style)
        """
        stylistic = self._extract_stylistic(X_raw)
        stylistic_scaled = self.stylistic_scaler.transform(stylistic)

        return hstack([
            csr_matrix(stylistic_scaled),            # v_style (dense → sparse)
            self.hash_vectorizer.transform(X_cleaned),  # v_lex (hashing)
            self.tfidf_vectorizer.transform(X_cleaned), # v_lex (tfidf supplement)
        ])

    # ------------------------------------------------------------------
    def fit_transform(self, X_raw, X_cleaned):
        self.fit(X_raw, X_cleaned)
        return self.transform(X_raw, X_cleaned)
