"""
src/evaluation/metrics.py

Evaluation utilities for the Edge-Device Dilemma experiments.

Covers:
  - In-domain accuracy and F1 (Phase I)
  - Edge latency measurement protocol (§3.4.1)
  - Model footprint quantification (§3.4.1)
  - Robustness decay metrics Δ and ρ (§3.4.2, Eqs. 6–7)
  - Results table formatting
"""

import gc
import os
import time

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score


# ---------------------------------------------------------------------------
# Latency measurement
# ---------------------------------------------------------------------------

def measure_edge_latency(
    predict_fn,
    X_samples,
    warmup: int = 1000,
    measurement: int = 10_000,
) -> float:
    """
    Measure single-sample inference latency using the protocol from §3.4.1:

      1. Disable garbage collection during measurement window.
      2. Warm-up: 1,000 iterations to load model weights into CPU cache.
      3. Measurement: 10,000 single-sample inferences with high-precision timer.

    Parameters
    ----------
    predict_fn : callable
        A function that accepts a list of one string and returns a prediction.
    X_samples : list or array-like
        Pool of samples to draw from (sampled with replacement).
    warmup : int
        Number of warm-up iterations (default 1,000).
    measurement : int
        Number of timed iterations (default 10,000).

    Returns
    -------
    float
        Mean latency in milliseconds per inference.
    """
    import random

    samples = list(X_samples)

    # Warm-up (loads weights into L2/L3 cache)
    for _ in range(warmup):
        predict_fn([random.choice(samples)])

    # Measurement
    gc.disable()
    total_ns = 0
    try:
        for _ in range(measurement):
            x = [random.choice(samples)]
            t0 = time.perf_counter_ns()
            predict_fn(x)
            t1 = time.perf_counter_ns()
            total_ns += t1 - t0
    finally:
        gc.enable()

    return (total_ns / measurement) / 1e6   # ns → ms


# ---------------------------------------------------------------------------
# Footprint measurement
# ---------------------------------------------------------------------------

def get_model_size_mb(model, model_type: str = "sklearn") -> float:
    """
    Measure serialised model footprint in MB (§3.4.1).

    Parameters
    ----------
    model : fitted model object
    model_type : "sklearn" | "fasttext"

    Returns
    -------
    float  Size in MB.
    """
    tmp = "_footprint_tmp"
    try:
        if model_type == "sklearn":
            import joblib
            tmp += ".joblib"
            joblib.dump(model, tmp)
        elif model_type == "fasttext":
            tmp += ".bin"
            model.save_model(tmp)
        else:
            raise ValueError(f"Unknown model_type: {model_type}")
        return os.path.getsize(tmp) / (1024 * 1024)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


# ---------------------------------------------------------------------------
# Robustness decay metrics (Eqs. 6–7)
# ---------------------------------------------------------------------------

def compute_robustness_decay(src_acc: float, tgt_acc: float) -> dict:
    """
    Compute Absolute Robustness Decay (Δ) and Relative Decay Ratio (ρ).

    Δ = Acc_source − Acc_target                  (Eq. 6)
    ρ = (Δ / Acc_source) × 100                   (Eq. 7)

    A high ρ indicates the model overfit to the source vocabulary.
    """
    delta = src_acc - tgt_acc
    rho   = (delta / src_acc) * 100 if src_acc > 0 else 0.0
    return {"delta": delta, "rho_pct": rho}


# ---------------------------------------------------------------------------
# Evaluation runner
# ---------------------------------------------------------------------------

def evaluate_model(y_true, y_pred) -> dict:
    """Return accuracy and macro-F1 for a set of predictions."""
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "f1":       f1_score(y_true, y_pred, average="macro"),
    }


# ---------------------------------------------------------------------------
# Results table
# ---------------------------------------------------------------------------

def build_results_table(results: list) -> pd.DataFrame:
    """
    Build a formatted DataFrame from a list of result dicts.

    Each dict should contain keys such as:
      model, accuracy, f1, latency_ms, size_mb,
      target_accuracy (optional), delta (optional), rho_pct (optional)
    """
    df = pd.DataFrame(results)
    # Reorder columns if present
    preferred = [
        "model", "accuracy", "f1", "target_accuracy",
        "delta", "rho_pct", "latency_ms", "size_mb",
    ]
    cols = [c for c in preferred if c in df.columns] + [
        c for c in df.columns if c not in preferred
    ]
    return df[cols].set_index("model") if "model" in df.columns else df


def print_results_table(df: pd.DataFrame, title: str = "Results") -> None:
    """Pretty-print a results DataFrame."""
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)
    try:
        print(df.to_markdown(floatfmt=".4f"))
    except ImportError:
        print(df.to_string())
    print("=" * 70)
