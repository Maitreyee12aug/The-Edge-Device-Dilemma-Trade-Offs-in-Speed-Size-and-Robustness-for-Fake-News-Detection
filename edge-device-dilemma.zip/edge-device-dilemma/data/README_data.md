# Data Preparation Guide

This project uses two publicly available datasets. **Do not commit the raw CSV files to Git** — add `data/*.csv` to your `.gitignore`.

---

## Dataset 1: ISOT Fake News Dataset (Political Corpus)

- **Role in paper:** Primary in-domain training/source domain for cross-domain experiments
- **Size:** ~44,898 articles (23,481 Fake / 21,417 Real)
- **Download:** https://onlineacademiccommunity.uvic.ca/isot/2022/11/27/fake-news-detection-datasets/

### Preparation

1. Download the ISOT archive and extract it.
2. Concatenate `Fake.csv` and `True.csv`:

```python
import pandas as pd

fake = pd.read_csv("Fake.csv")
fake["label"] = "fake"

real = pd.read_csv("True.csv")
real["label"] = "real"

combined = pd.concat([fake, real], ignore_index=True)

# The paper uses a 'tweet' column name for the text field
combined = combined.rename(columns={"text": "tweet"})
combined[["tweet", "label"]].to_csv("data/concatenated_dataset.csv", index=False)
```

3. Confirm the file has columns: `tweet`, `label` (values: `real` / `fake`).

---

## Dataset 2: CONSTRAINT 2021 COVID-19 Fake News (COVID Corpus)

- **Role in paper:** Zero-shot transfer target domain / low-resource source domain
- **Size:** 6,420 tweets (3,210 Fake / 3,210 Real)
- **Download:** https://constraint-shared-task-2021.github.io/

### Preparation

1. Download `Constraint_Train.xlsx` or `Constraint_Train.csv` from the shared task page.
2. Place it at `data/Constraint_Train.csv`.
3. Confirm the file has columns: `tweet`, `label` (values: `real` / `fake`).

---

## Expected Directory Layout

```
data/
  concatenated_dataset.csv    ← Political corpus (ISOT, ~44k rows)
  Constraint_Train.csv        ← COVID-19 corpus (CONSTRAINT 2021, ~6k rows)
  README_data.md              ← This file
```

---

## Column Configuration

If your CSV files use different column names or label values, update `configs/config.yaml` accordingly — no code changes are required.

```yaml
data:
  political_text_col:  "tweet"   # change to e.g. "text" or "title"
  political_label_col: "label"
  political_real_val:  "real"
  political_fake_val:  "fake"
```

---

## Duplicate Screening

Both datasets were screened for exact duplicate articles prior to model training. No overlapping samples were found between the Political and COVID-19 corpora, ensuring clean zero-shot evaluation.
